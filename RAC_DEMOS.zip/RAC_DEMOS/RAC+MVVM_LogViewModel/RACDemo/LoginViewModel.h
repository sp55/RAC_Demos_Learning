//
//  LoginViewModel.h
//  RACDemo
//
//  Created by admin on 2017/10/24.
//  Copyright © 2017年 AlezJi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LoginViewModel : NSObject

@end
