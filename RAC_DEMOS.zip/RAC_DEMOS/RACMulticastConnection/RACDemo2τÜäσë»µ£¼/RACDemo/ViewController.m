//
//  ViewController.m
//  RACDemo
//
//  Created by admin on 2017/10/20.
//  Copyright © 2017年 AlezJi. All rights reserved.
//http://www.cocoachina.com/ios/20150820/13071.html

#import "ViewController.h"
#import "ReactiveCocoa.h"


@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
