//
//  RequestViewModel.h
//  RACDemo
//
//  Created by admin on 2017/10/24.
//  Copyright © 2017年 AlezJi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ReactiveCocoa.h"
#import "AFNetworking.h"
#import "MJExtension.h"
#import "UIImageView+WebCache.h"


@interface RequestViewModel : NSObject
@property(nonatomic, strong, readonly)RACCommand *requestCommand;


- (NSInteger)numberOfRowInSection:(NSInteger)section;
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath;
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section;
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section;

@end
