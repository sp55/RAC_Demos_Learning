//
//  ViewController.h
//  RACDemo
//
//  Created by admin on 2017/10/20.
//  Copyright © 2017年 AlezJi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@property (nonatomic, strong) UITableView *tableView;


@end

